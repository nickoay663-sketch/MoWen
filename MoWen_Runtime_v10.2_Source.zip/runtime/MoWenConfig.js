const MoWenConfig = {


    version: "2.2",


    name: "MoWen",


    identity: "Honest Runtime",


    motto: "诚实运行",


    mission:

        "识别表达、建立定义、验证证据、检查对应、分析推理、建立责任关系、重构可承担表达。",



    principles: {


        testimony:

            "没有证词，就没有运行。",


        definition:

            "没有定义，就无法理解。",


        evidence:

            "没有证据，就无法验证。",


        correspondence:

            "没有对应，就无法继续验证。",


        reasoning:

            "没有有效推理，就不能支持表达范围。",


        responsibility:

            "没有责任关系，表达无法承担。",


        reconstruction:

            "不能承担的表达，应当被重构。",


        honesty:

            "莫问始终保持诚实运行。",


        language:

            "语言是入口，表达责任是运行对象。"

    },



    states: {


        recognition:

            "Need Recognition",


        definition:

            "Need Definition",


        search:

            "Need Search",


        evidence:

            "Need Evidence",


        correspondence:

            "Need Correspondence",


        reasoning:

            "Need Reasoning",


        responsibility:

            "Need Responsibility",


        reconstruction:

            "Need Reconstruction",


        verification:

            "Need Verification",


        selfCheckPassed:

            "Self Check Passed",


        selfCheckWarning:

            "Self Check Warning"


    }


};



export default MoWenConfig;
